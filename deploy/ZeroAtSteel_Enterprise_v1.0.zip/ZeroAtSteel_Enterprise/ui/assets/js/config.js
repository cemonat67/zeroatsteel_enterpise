window.ZERO_STEEL_CONFIG = {
  ENV: "production",
  SUPABASE_URL: "https://YOUR_PROJECT.supabase.co",
  SUPABASE_KEY: "YOUR_ANON_KEY",
  N8N_URL: "https://YOUR_N8N_SERVER/webhook"
}
