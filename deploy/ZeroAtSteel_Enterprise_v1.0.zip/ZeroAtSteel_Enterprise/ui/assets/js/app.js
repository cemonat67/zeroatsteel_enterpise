const cfg = window.ZERO_STEEL_CONFIG
document.getElementById('env').textContent = cfg.ENV

async function loadFurnaces() {
  const r = await fetch(`${cfg.SUPABASE_URL}/rest/v1/furnaces?select=*`, {
    headers: { apikey: cfg.SUPABASE_KEY, Authorization: `Bearer ${cfg.SUPABASE_KEY}` }
  })
  return await r.json()
}

async function checkHealth() {
  const r = await fetch(`${cfg.SUPABASE_URL}/rest/v1/v_system_status?select=*`, {
    headers: { apikey: cfg.SUPABASE_KEY, Authorization: `Bearer ${cfg.SUPABASE_KEY}` }
  })
  const d = await r.json()
  return d && d[0] ? d[0] : {}
}

async function askAI(prompt) {
  const r = await fetch(`${cfg.N8N_URL}/zero-steel/ai-analyze`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt })
  })
  return await r.json()
}

async function boot() {
  const furnaces = await loadFurnaces()
  const fEl = document.getElementById('furnaces')
  fEl.innerHTML = ''
  furnaces.forEach(f => {
    const row = document.createElement('div')
    row.textContent = `${f.id || ''} ${f.name || ''} ${f.status || ''}`
    fEl.appendChild(row)
  })

  const h = await checkHealth()
  document.getElementById('health').textContent = JSON.stringify(h, null, 2)

  document.getElementById('ask').addEventListener('click', async () => {
    const prompt = document.getElementById('prompt').value.trim()
    if (!prompt) return
    const resp = await askAI(prompt)
    document.getElementById('ai').textContent = JSON.stringify(resp, null, 2)
  })
}

boot()
